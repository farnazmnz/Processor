
#read assembly code
lines = []                             
with open ('c:/Users/Asus/Desktop/assembly.asm', 'rt') as testfile: 
    for line in testfile:                
        lines.append(line)           
testfile.close()


k=0
error=0
bin_code=[]
elements=[]
tmp=[]  #array to store register
strn=[]  #array to store register's number


for i in range(len(lines)):
    elements.append(lines[i].split(" "))
    tmp.append("".join(lines[i].split(" ")[1:]))
    strn.append(tmp[i].strip("\n"))


    # LOAD instruction 
    if elements[i][0].upper()=="LOAD":
        bin_code.append("000")      # op code : 000

        #convert register's number to  binary
        if strn[i][1]=="0":
            bin_code[k]=bin_code[k]+"0011" 
        elif strn[i][1]=="1":
            bin_code[k]=bin_code[k]+"0111"
        elif strn[i][1]=="2":
            bin_code[k]=bin_code[k]+"1011"
        elif strn[i][1]=="3":
            bin_code[k]=bin_code[k]+"1111" 
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1
            break
        bin_code.append(bin(int(strn[i][3:]))[2:].zfill(7))
        k+=2


     # ADD instruction
    elif elements[i][0].upper()=="ADD":
        bin_code.append("001")

        #first register
        if strn[i][1]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][1]=="1":
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][1]=="2":
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][1]=="3":
            bin_code[k]=bin_code[k]+"11"
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1
            break

        #second register
        if strn[i][4]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][4]=="1": 
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][4]=="2": 
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][4]=="3": 
            bin_code[k]=bin_code[k]+"11" 
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1           
            break
        k+=1    
    
    # SUB instruction
    elif elements[i][0].upper()=="SUB":
        bin_code.append("010")

        #first register
        if strn[i][1]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][1]=="1":
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][1]=="2":
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][1]=="3":
            bin_code[k]=bin_code[k]+"11"
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1
            break

        #second register
        if strn[i][4]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][4]=="1": 
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][4]=="2": 
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][4]=="3": 
            bin_code[k]=bin_code[k]+"11" 
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1           
            break
        k+=1  
    
    # MUL instruction
    elif elements[i][0].upper()=="MUL":
        bin_code.append("100")

        #first register
        if strn[i][1]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][1]=="1":
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][1]=="2":
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][1]=="3":
            bin_code[k]=bin_code[k]+"11"
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1
            break

        #second register
        if strn[i][4]=="0":
            bin_code[k]=bin_code[k]+"00" 
        elif strn[i][4]=="1": 
            bin_code[k]=bin_code[k]+"01"
        elif strn[i][4]=="2": 
            bin_code[k]=bin_code[k]+"10"
        elif strn[i][4]=="3": 
            bin_code[k]=bin_code[k]+"11" 
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1           
            break
        k+=1    
    
    #JNZ instruction
    elif elements[i][0].upper()=="JNZ":
        bin_code.append("011")     

        #convert register's number to  binary
        if strn[i][1]=="0":
            bin_code[k]=bin_code[k]+"0011" 
        elif strn[i][1]=="1":
            bin_code[k]=bin_code[k]+"0111"
        elif strn[i][1]=="2":
            bin_code[k]=bin_code[k]+"1011"
        elif strn[i][1]=="3":
            bin_code[k]=bin_code[k]+"1111" 
        elif int(strn[i][1])>3 or int(strn[i][1])<0:
            print("ERROR ! register's number should be from 0 to 3.")
            error=1
            break
        bin_code.append(bin(int(strn[i][3:]))[2:].zfill(7))
        k+=2
    

    # HLT
    elif elements[i][0].strip("\n").upper()=="HLT":   
        bin_code.append("000000")
        K+=1



# sample of VHDL code :

line1="library IEEE;"
line2="use IEEE.STD_LOGIC_1164.all;"
line3="use IEEE.Numeric_Std.all;"
line4="entity Memory is"
line5="	 port("
line6="		 Address : in STD_LOGIC_VECTOR(5 downto 0);"
line7="		 Mdata : out STD_LOGIC_VECTOR(5 downto 0)"
line8="	     );"
line9="end Memory;"
line10="architecture Memory of Memory is"
line11="type mem is array(63 downto 0) of std_logic_vector(5 downto 0);"
line12="signal memory : mem;"
line13="begin"
line14="Mdata <= memory(to_integer(unsigned(Address)));"
line15=[]
line16="end ROM_Memory;"


for i in range(len(bin_code)):
    
    line15.append("memory("+str(i)+") <="+' "' +str(bin_code[i])+'"'+';' )
                                   
lines = [line1,line2,line3,'\n',line4,line5,line6,line7,line8,line9,'\n',line10,line11,line12,line13,'\n',line14,'\n']


# write in vhdl file

if error == 0:
    with open('c:/Users/Asus/Desktop/Memory.vhd', 'w') as f:
        f.write('\n'.join(lines))
        for item in line15:
            f.write("%s\n" % item) 
        f.write('\n'+line16)    
        f.close()
